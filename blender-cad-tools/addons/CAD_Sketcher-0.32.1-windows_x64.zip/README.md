[![CAD Sketcher](/resources/logos/wide_dark.png)](https://hlorus.github.io/CAD_Sketcher/#gh-light-mode-only)
[![CAD Sketcher](/resources/logos/wide_light.png)](https://hlorus.github.io/CAD_Sketcher/#gh-dark-mode-only)

#
<a href="https://discord.gg/GzpJsShgxa"><img alt="Discord" src="https://img.shields.io/discord/882152824249667594"></a>
![GitHub issues by-label](<https://img.shields.io/github/issues/hlorus/CAD_Sketcher/feature request>)
![GitHub issues by-label](https://img.shields.io/github/issues/hlorus/CAD_Sketcher/bug)

Constraint-based sketcher extension for [Blender](https://www.blender.org/) that allows to create precise 2d shapes by defining a set of geometric constraints like tangent, distance, angle, equal and more. Sketches stay editable and support a fully non-destructive workflow.

> :warning: **Experimental extension:** This is still work in progress, don't use it on production files without a backup.

Minimum version: Blender 5.0

## More than just an extension learn more: [CADsketcher.com](http://cadsketcher.com/)

## Links:

 - [Preferred Download Method](https://gumroad.com/a/891069555) (This way we can update you about big updates and ask your opinion on big changes)
 - [Easy To Read Roadmap](https://www.cadsketcher.com/cad-sketcher-roadmap)
 - [Github Roadmap](https://github.com/users/hlorus/projects/1)
 - [Documentation](https://hlorus.github.io/CAD_Sketcher/)
 - [Installation](https://hlorus.github.io/CAD_Sketcher/installation)
 - [Discord](https://discord.gg/GzpJsShgxa)
 - [Report A Bug](https://github.com/hlorus/CAD_Sketcher/discussions/107)
 - [Feature Request](https://github.com/hlorus/CAD_Sketcher/discussions/106)
 - [Contribute](https://hlorus.github.io/CAD_Sketcher/advanced/#contribute)


## Extension installation

### Recommended: add the extension repository (auto-updates)

Adding CAD Sketcher as a remote repository lets Blender install and **update** it in-app:

1. In Blender go to `Edit > Preferences > Get Extensions`.
2. Open the repositories drop-down (arrow in the top-right corner) and choose **Add Remote Repository**.
3. Paste the URL below, tick **Check for Updates on Startup**, and confirm:
   ```
   https://hlorus.github.io/CAD_Sketcher-extensions/stable/index.json
   ```
4. CAD Sketcher now appears in the extensions list — press **Install**.

### Other methods

For alternative installation methods (ZIP file, legacy add-on, git) and solver-dependency / Python-version notes, see the [installation guide](https://hlorus.github.io/CAD_Sketcher/installation/).


## Usage
Follow the [getting started](https://hlorus.github.io/CAD_Sketcher/getting_started) guide to get familiar with the extension.

## Donations :heart:
The project accepts donations through Open Collective.

<p>
<a href="https://opencollective.com/cadsketcher/contribute">
<img src="https://user-images.githubusercontent.com/64740362/182779318-b17ce498-f872-4a60-94c5-50391ec1e119.svg" width="300">
</a>
</p>

Alternatively individual developers can link their donation links here:

<a href="https://github.com/sponsors/hlorus">
hlorus - Lead Dev
</a>
