import bpy

from .angle import VIEW3D_GGT_slvs_angle, VIEW3D_GT_slvs_angle
from .base import use_plain_attributes
from .constraint import (
    VIEW3D_GGT_slvs_constraint,
    VIEW3D_GT_slvs_constraint,
    VIEW3D_GT_slvs_constraint_value,
)
from .diameter import VIEW3D_GGT_slvs_diameter, VIEW3D_GT_slvs_diameter
from .distance import VIEW3D_GGT_slvs_distance, VIEW3D_GT_slvs_distance
from .object_hover import (
    VIEW3D_GGT_slvs_object_hover,
    VIEW3D_GT_slvs_object_hover,
)
from .preselection import (
    VIEW3D_GGT_slvs_preselection,
    VIEW3D_GT_slvs_preselection,
)
from .workplane import (
    VIEW3D_GGT_slvs_workplane,
    VIEW3D_GT_slvs_workplane,
)

specific_constraint_types = ("angle", "diameter", "distance")


classes = (
    VIEW3D_GT_slvs_preselection,
    VIEW3D_GT_slvs_constraint,
    VIEW3D_GT_slvs_distance,
    VIEW3D_GT_slvs_angle,
    VIEW3D_GT_slvs_diameter,
    VIEW3D_GT_slvs_constraint_value,
    VIEW3D_GT_slvs_workplane,
    VIEW3D_GT_slvs_object_hover,
    VIEW3D_GGT_slvs_preselection,
    VIEW3D_GGT_slvs_constraint,
    VIEW3D_GGT_slvs_distance,
    VIEW3D_GGT_slvs_angle,
    VIEW3D_GGT_slvs_diameter,
    VIEW3D_GGT_slvs_workplane,
    VIEW3D_GGT_slvs_object_hover,
)


def register():
    for cls in (
        VIEW3D_GT_slvs_constraint,
        VIEW3D_GT_slvs_constraint_value,
        VIEW3D_GT_slvs_distance,
        VIEW3D_GT_slvs_angle,
        VIEW3D_GT_slvs_diameter,
    ):
        use_plain_attributes(cls)
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
