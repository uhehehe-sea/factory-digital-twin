import logging

from bpy.props import FloatProperty
from bpy.types import Context, Operator

from ..curve_solver import solve_system
from ..declarations import Operators
from ..drawing import selection
from ..model.coincident import SlvsCoincident
from ..model.equal import SlvsEqual
from ..model.horizontal import SlvsHorizontal
from ..model.midpoint import SlvsMidpoint
from ..model.parallel import SlvsParallel
from ..model.perpendicular import SlvsPerpendicular
from ..model.ratio import SlvsRatio
from ..model.tangent import SlvsTangent
from ..model.vertical import SlvsVertical
from ..stateful_operator.utilities.register import register_stateops_factory
from ..utilities.select import deselect_all
from ..utilities.view import refresh
from .base_constraint import GenericConstraintOp

logger = logging.getLogger(__name__)


def merge_points(context, duplicate, target):
    """Merge two point curves: remap all references from duplicate to target, then delete duplicate."""
    from ..model.sketch_ref import get_active_sketch
    sketch = get_active_sketch(context)
    if not sketch or not sketch.target_object or not sketch.target_object.data:
        return

    cd = sketch.target_object.data
    from ..utilities.curve_data import get_uuid, set_uuid
    dup_cid = duplicate.curve_id
    tgt_cid = target.curve_id

    # Remap relationship attributes
    for attr_name in ("start_point_id", "end_point_id", "center_point_id"):
        for i in range(len(cd.curves)):
            if get_uuid(cd, attr_name, i) == dup_cid:
                set_uuid(cd, attr_name, i, tgt_cid)

    # Remap constraint curve_ids
    for c in sketch.constraints.all:
        if getattr(c, "curve_id_1", 0) == dup_cid:
            c.curve_id_1 = tgt_cid
        if getattr(c, "curve_id_2", 0) == dup_cid:
            c.curve_id_2 = tgt_cid
        if getattr(c, "curve_id_3", 0) == dup_cid:
            c.curve_id_3 = tgt_cid

    # The remap can leave three kinds of redundant constraint behind, all of which
    # the solver reports as failed/redundant:
    #  - self-referential: a coincident joining the two merged points now points
    #    target->target (a point coincident with itself);
    #  - duplicate: two points each constrained to the same third entity (another
    #    point, a line, a circle...) collapse to identical constraints;
    #  - point-on-own-curve: a coincident that put a point onto a curve now targets
    #    that curve's own endpoint (e.g. merging an on-line point onto the line's
    #    end), so the point lies on the curve by construction.
    # Drop them so the merge leaves a clean, solvable sketch.
    _remove_redundant_constraints(sketch, sketch.constraints)

    # Remove duplicate
    duplicate.remove()


def _constraint_operands(c):
    """The non-empty curve references of a constraint, order-insensitive."""
    ids = (
        getattr(c, "curve_id_1", ""),
        getattr(c, "curve_id_2", ""),
        getattr(c, "curve_id_3", ""),
    )
    return frozenset(i for i in ids if i)


def _point_is_structural_end(sketch, point_id, curve_id):
    """True if ``point_id`` is a start/end/center point of curve ``curve_id``."""
    from ..utilities.curve_data import get_curve_data, get_uuid, has_uuid_field

    if not point_id or not curve_id or point_id == curve_id:
        return False
    cd, idx, _ = get_curve_data(sketch, curve_id)
    if cd is None:
        return False
    for field in ("start_point_id", "end_point_id", "center_point_id"):
        if has_uuid_field(cd, field) and get_uuid(cd, field, idx) == point_id:
            return True
    return False


def _is_redundant_point_on_curve(sketch, c):
    """A coincident whose point operand is already a structural end of its curve."""
    if c.type != "COINCIDENT":
        return False
    id1 = getattr(c, "curve_id_1", "")
    id2 = getattr(c, "curve_id_2", "")
    return _point_is_structural_end(sketch, id1, id2) or _point_is_structural_end(
        sketch, id2, id1
    )


def _remove_redundant_constraints(sketch, constraints):
    """Drop self-referential, duplicate and point-on-own-curve constraints left by
    a merge remap.

    Removes one constraint per pass and rescans, so a held reference is never used
    across a collection mutation (which would invalidate it)."""
    while True:
        victim = None
        seen = {}
        for c in constraints.all:
            id1 = getattr(c, "curve_id_1", "")
            if id1 and id1 == getattr(c, "curve_id_2", ""):
                victim = c  # self-referential
                break
            if _is_redundant_point_on_curve(sketch, c):
                victim = c  # point already lies on the curve by construction
                break
            key = (c.type, _constraint_operands(c))
            if key in seen:
                victim = c  # duplicate of an earlier constraint
                break
            seen[key] = c
        if victim is None:
            return
        constraints.remove(victim)


class VIEW3D_OT_slvs_merge_points(Operator):
    """Merge selected points"""

    bl_idname = Operators.MergePoints
    bl_label = "Merge Points"
    bl_options = {"UNDO", "REGISTER"}

    @classmethod
    def poll(cls, context: Context):
        from ..model.sketch_ref import get_active_sketch
        return bool(get_active_sketch(context))

    def execute(self, context: Context):
        from ..model.curve_ref import curve_ref
        from ..model.sketch_ref import get_active_sketch

        sketch = get_active_sketch(context)
        if not sketch:
            return {"CANCELLED"}

        points = [
            curve_ref(sketch, cid)
            for cid in selection.selected
            if curve_ref(sketch, cid).is_point()
        ]

        if len(points) < 2:
            self.report({"WARNING"}, "Select at least two points to merge")
            return {"CANCELLED"}

        fixed_points = [p for p in points if p.fixed]
        if len(fixed_points) > 1:
            self.report({"WARNING"}, "Cannot merge multiple fixed points")
            return {"CANCELLED"}

        target = fixed_points[0] if fixed_points else points[-1]
        duplicates = [p for p in points if p.curve_id != target.curve_id]

        for dup in duplicates:
            merge_points(context, dup, target)

        # Delete collapsed lines (start == end after merge)
        collapsed = []
        cd = sketch.target_object.data
        from ..utilities.curve_data import get_uuid, has_uuid_field
        if has_uuid_field(cd, "start_point_id") and has_uuid_field(cd, "end_point_id"):
            for i in range(len(cd.curves)):
                sp = get_uuid(cd, "start_point_id", i)
                ep = get_uuid(cd, "end_point_id", i)
                if sp and ep and sp == ep:
                    collapsed.append(get_uuid(cd, "curve_id", i))
            for cid in collapsed:
                curve_ref(sketch, cid).remove()

        deselect_all(context)
        selection.selected.append(target.curve_id)

        solve_system(context, sketch)
        refresh(context)

        n = len(duplicates)
        if collapsed:
            self.report({"INFO"}, f"Merged {n} point(s) and deleted {len(collapsed)} collapsed line(s)")
        else:
            self.report({"INFO"}, f"Merged {n} point(s)")
        return {"FINISHED"}


class VIEW3D_OT_slvs_add_coincident(Operator, GenericConstraintOp):
    """Add a coincident constraint"""

    bl_idname = Operators.AddCoincident
    bl_label = "Coincident"
    bl_options = {"UNDO", "REGISTER"}

    type = "COINCIDENT"

    def handle_merge(self, context):
        points = self.entity1, self.entity2

        if not all([e.is_point() for e in points]):
            return False

        for p1, p2 in (points, reversed(points)):
            if p1.fixed:
                continue

            merge_points(context, p1, p2)
            from ..model.sketch_ref import get_active_sketch
            solve_system(context, get_active_sketch(context))
            break
        return True

    def main(self, context: Context):
        # Implicitly merge points
        if self.handle_merge(context):
            return True

        if not self.exists(context, SlvsCoincident):
            self.target = self.sketch.constraints.add_coincident(
                
                curve_id_1=self.entity1.curve_id,
                curve_id_2=self.entity2.curve_id,
            )
        return super().main(context)


class VIEW3D_OT_slvs_add_equal(Operator, GenericConstraintOp):
    """Add an equal constraint"""

    bl_idname = Operators.AddEqual
    bl_label = "Equal"
    bl_options = {"UNDO", "REGISTER"}

    type = "EQUAL"

    def main(self, context):
        if not self.exists(context, SlvsEqual):
            self.target = self.sketch.constraints.add_equal(
                curve_id_1=self.entity1.curve_id,
                curve_id_2=self.entity2.curve_id,
            )

        return super().main(context)


class VIEW3D_OT_slvs_add_vertical(Operator, GenericConstraintOp):
    """Add a vertical constraint"""

    bl_idname = Operators.AddVertical
    bl_label = "Vertical"
    bl_options = {"UNDO", "REGISTER"}

    type = "VERTICAL"

    def main(self, context):
        if not self.exists(context, SlvsVertical):
            self.target = self.sketch.constraints.add_vertical(
                
                curve_id_1=self.entity1.curve_id,
                curve_id_2=self.entity2.curve_id if self.entity2 else "",
            )

        return super().main(context)


class VIEW3D_OT_slvs_add_horizontal(Operator, GenericConstraintOp):
    """Add a horizontal constraint"""

    bl_idname = Operators.AddHorizontal
    bl_label = "Horizontal"
    bl_options = {"UNDO", "REGISTER"}

    type = "HORIZONTAL"

    def main(self, context):
        if not self.exists(context, SlvsHorizontal):
            self.target = self.sketch.constraints.add_horizontal(
                
                curve_id_1=self.entity1.curve_id,
                curve_id_2=self.entity2.curve_id if self.entity2 else "",
            )

        return super().main(context)


class VIEW3D_OT_slvs_add_parallel(Operator, GenericConstraintOp):
    """Add a parallel constraint"""

    bl_idname = Operators.AddParallel
    bl_label = "Parallel"
    bl_options = {"UNDO", "REGISTER"}

    type = "PARALLEL"

    def main(self, context):
        if not self.exists(context, SlvsParallel):
            self.target = self.sketch.constraints.add_parallel(
                
                curve_id_1=self.entity1.curve_id,
                curve_id_2=self.entity2.curve_id,
            )

        return super().main(context)


class VIEW3D_OT_slvs_add_perpendicular(Operator, GenericConstraintOp):
    """Add a perpendicular constraint"""

    bl_idname = Operators.AddPerpendicular
    bl_label = "Perpendicular"
    bl_options = {"UNDO", "REGISTER"}

    type = "PERPENDICULAR"

    def main(self, context):
        if not self.exists(context, SlvsPerpendicular):
            self.target = self.sketch.constraints.add_perpendicular(
                
                curve_id_1=self.entity1.curve_id,
                curve_id_2=self.entity2.curve_id,
            )

        return super().main(context)


class VIEW3D_OT_slvs_add_tangent(Operator, GenericConstraintOp):
    """Add a tangent constraint"""

    bl_idname = Operators.AddTangent
    bl_label = "Tangent"
    bl_options = {"UNDO", "REGISTER"}

    type = "TANGENT"

    def main(self, context):
        if not self.exists(context, SlvsTangent):
            self.target = self.sketch.constraints.add_tangent(
                
                curve_id_1=self.entity1.curve_id,
                curve_id_2=self.entity2.curve_id,
            )

        return super().main(context)


class VIEW3D_OT_slvs_add_midpoint(Operator, GenericConstraintOp):
    """Add a midpoint constraint"""

    bl_idname = Operators.AddMidPoint
    bl_label = "Midpoint"
    bl_options = {"UNDO", "REGISTER"}

    type = "MIDPOINT"

    def main(self, context):
        if not self.exists(context, SlvsMidpoint):
            self.target = self.sketch.constraints.add_midpoint(
                
                curve_id_1=self.entity1.curve_id,
                curve_id_2=self.entity2.curve_id,
            )

        return super().main(context)


class VIEW3D_OT_slvs_add_ratio(Operator, GenericConstraintOp):
    """Add a ratio constraint"""

    bl_idname = Operators.AddRatio
    bl_label = "Ratio"
    bl_options = {"UNDO", "REGISTER"}

    value: FloatProperty(
        name="Ratio",
        subtype="UNSIGNED",
        options={"SKIP_SAVE"},
        min=0.0,
        precision=5,
    )
    type = "RATIO"
    property_keys = ("value",)

    def main(self, context):
        if not self.exists(context, SlvsRatio):
            self.target = self.sketch.constraints.add_ratio(
                
                init=not self.initialized,
                curve_id_1=self.entity1.curve_id,
                curve_id_2=self.entity2.curve_id,
                **self.get_settings(),
            )

        return super().main(context)


class VIEW3D_OT_slvs_add_symmetry(Operator, GenericConstraintOp):
    """Add a symmetry constraint"""

    bl_idname = Operators.AddSymmetry
    bl_label = "Symmetry"
    bl_options = {"UNDO", "REGISTER"}

    type = "SYMMETRY"

    def main(self, context):
        if not self.exists(context, SlvsRatio):
            self.target = self.sketch.constraints.add_symmetry(
                
                curve_id_1=self.entity1.curve_id,
                curve_id_2=self.entity2.curve_id,
                curve_id_3=self.entity3.curve_id,
            )

        return super().main(context)


constraint_operators = (
    VIEW3D_OT_slvs_add_coincident,
    VIEW3D_OT_slvs_merge_points,
    VIEW3D_OT_slvs_add_equal,
    VIEW3D_OT_slvs_add_vertical,
    VIEW3D_OT_slvs_add_horizontal,
    VIEW3D_OT_slvs_add_parallel,
    VIEW3D_OT_slvs_add_perpendicular,
    VIEW3D_OT_slvs_add_tangent,
    VIEW3D_OT_slvs_add_midpoint,
    VIEW3D_OT_slvs_add_ratio,
    VIEW3D_OT_slvs_add_symmetry,
)

register, unregister = register_stateops_factory(constraint_operators)
