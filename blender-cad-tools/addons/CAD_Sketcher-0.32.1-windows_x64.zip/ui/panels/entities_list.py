from bpy.types import Context

from ... import icon_manager
from ...drawing import selection
from ...model.constants import SketchCurveType
from ...model.sketch_ref import get_active_sketch
from ...utilities.curve_data import get_str_attr, get_uuid, has_uuid_field
from .. import declarations
from . import VIEW3D_PT_sketcher_base

_TYPE_NAMES = {
    SketchCurveType.POINT: "Point",
    SketchCurveType.LINE: "Line",
    SketchCurveType.ARC: "Arc",
    SketchCurveType.CIRCLE: "Circle",
}


class VIEW3D_PT_sketcher_entities(VIEW3D_PT_sketcher_base):
    """Entities Menu: List of curves in the active sketch."""

    bl_label = "Entities"
    bl_idname = declarations.Panels.SketcherEntities
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        return get_active_sketch(context) is not None

    def draw(self, context: Context):
        layout = self.layout
        box = layout.box()
        col = box.column(align=True)
        col.scale_y = 0.8

        sketch = get_active_sketch(context)
        if not sketch or not sketch.target_object or not sketch.target_object.data:
            return

        curve_data = sketch.target_object.data
        n = len(curve_data.curves)
        type_attr = curve_data.attributes.get("sketch_type")
        vis_attr = curve_data.attributes.get("visible")
        construction_attr = curve_data.attributes.get("construction")
        name_attr = curve_data.attributes.get("name")
        if not has_uuid_field(curve_data, "curve_id") or not type_attr:
            return

        for i in range(n):
            cid = get_uuid(curve_data, "curve_id", i)
            if not cid:
                continue

            ctype = type_attr.data[i].value
            visible = vis_attr.data[i].value if vis_attr else True
            construction = (
                construction_attr.data[i].value if construction_attr else False
            )
            selected = cid in selection.selected
            # Stored name (set at creation), falling back to the type label.
            name = (get_str_attr(name_attr, i) if name_attr else "") or _TYPE_NAMES.get(
                ctype, "Curve"
            )

            row = col.row()
            row.alert = selected

            # Leading toggles, grouped so they sit flush together
            lead = row.row(align=True)

            # Select toggle
            props = lead.operator(
                declarations.Operators.Select,
                text="",
                emboss=False,
                icon=("RADIOBUT_ON" if selected else "RADIOBUT_OFF"),
            )
            props.mode = "TOGGLE"
            props.index = cid

            # Visibility toggle
            props = lead.operator(
                declarations.Operators.SetCurveFlag,
                text="",
                emboss=False,
                icon=("HIDE_OFF" if visible else "HIDE_ON"),
            )
            props.curve_id = cid
            props.flag = "visible"
            props.value = not visible

            # Name — click to rename, prefixed by the entity type icon (dashed
            # for construction geometry). Left-aligned, so the icon and the name
            # line up across rows.
            name_row = row.row()
            name_row.alignment = "LEFT"
            props = name_row.operator(
                declarations.Operators.RenameCurve,
                text=name,
                emboss=False,
                icon_value=icon_manager.get_entity_icon(ctype, construction),
            )
            props.curve_id = cid
            props.new_name = name

            # Trailing actions, grouped so they sit flush together. The
            # left-aligned name row above expands to fill, pushing these right.
            trail = row.row(align=True)
            trail.alignment = "RIGHT"

            # Context menu
            props = trail.operator(
                declarations.Operators.ContextMenu,
                text="",
                icon="OUTLINER_DATA_GP_LAYER",
                emboss=False,
            )
            props.curve_id = cid
            props.highlight_hover = True

            # Delete
            props = trail.operator(
                declarations.Operators.DeleteEntity,
                text="",
                icon="X",
                emboss=False,
            )
            props.index = cid
            props.highlight_hover = True
