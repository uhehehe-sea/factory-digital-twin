from bpy.types import WorkSpaceTool

from ..declarations import GizmoGroups, Operators, WorkSpaceTools
from ..icon_manager import get_icon
from ..keymaps import tool_generic
from ..stateful_operator.tool import GenericStateTool
from ..stateful_operator.utilities.keymap import operator_access


class VIEW3D_T_slvs_add_point2d(GenericStateTool, WorkSpaceTool):
    bl_space_type = "VIEW_3D"
    bl_context_mode = "OBJECT"
    bl_idname = WorkSpaceTools.AddPoint2D
    bl_label = "Point"
    bl_description = "Add a point to the active sketch"
    bl_operator = Operators.AddPoint2D
    bl_icon = get_icon("ops.bgs.add_point")
    bl_widget = GizmoGroups.Preselection
    bl_keymap = (
        *tool_generic,
        *operator_access(Operators.AddPoint2D),
    )

    def draw_settings(context, layout, tool):
        layout.prop(
            context.scene.sketcher, "auto_axis_constraints", text="Auto Constraints"
        )
        layout.prop(
            context.scene.sketcher, "use_snap_project", text="Live Project Snaps"
        )
