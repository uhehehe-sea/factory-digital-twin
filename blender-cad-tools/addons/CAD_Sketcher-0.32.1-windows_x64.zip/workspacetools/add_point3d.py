from bpy.types import WorkSpaceTool

from ..declarations import GizmoGroups, Operators, WorkSpaceTools
from ..icon_manager import get_icon
from ..stateful_operator.tool import GenericStateTool
from ..stateful_operator.utilities.keymap import operator_access
from .keymaps_3d import tool_generic_3d


class VIEW3D_T_slvs_add_point3d(GenericStateTool, WorkSpaceTool):
    bl_space_type = "VIEW_3D"
    bl_context_mode = "OBJECT"
    bl_idname = WorkSpaceTools.AddPoint3D
    bl_label = "Point"
    bl_description = "Add a point to the active sketch"
    bl_operator = Operators.AddPoint3D
    bl_icon = get_icon("ops.bgs.add_point")
    bl_widget = GizmoGroups.Preselection
    bl_keymap = (
        *tool_generic_3d,
        *operator_access(Operators.AddPoint3D),
    )
